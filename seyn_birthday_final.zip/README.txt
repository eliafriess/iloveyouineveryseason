SEYN'S 21ST BIRTHDAY WEBSITE

Files:
- index.html — the finished website
- Add your 10 photo files to the same GitHub Pages folder as index.html.
- Main background song: it-might-be-you.mp3 (the page also falls back to it-might-be-you.mp3.mp3).

Other song Play buttons are ready, but each needs its matching audio file in the repository:
- love.mp3
- intertwine-ft-the-ridleys.mp3
- if-only.mp3
- disney.mp3

The editable fields save changes to this browser using localStorage. They do not change the GitHub files or automatically change what another person sees.
